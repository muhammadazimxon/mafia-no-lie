package com.example.mafiaonlinejetpackcomposecapi.viewModel

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.mafiaonlinejetpackcomposecapi.waitingRoomModels.waitingRoomDto.WaitingRoomDto
import com.microsoft.signalr.HubConnection
import com.microsoft.signalr.HubConnectionBuilder
import com.microsoft.signalr.HubConnectionState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Date

private const val SERVER_URL = "http://10.0.2.2:<port>/mafiaHub"

data class ChatMessage(
    val user: String,
    val message: String,
    val timeStamp: Date = Date()
)

data class SystemMessage(
    val content: String,
    val temStamp: Date = Date()
)

class WaitingRoomViewModel : ViewModel() {
    private val hubConnection: HubConnection = HubConnectionBuilder
        .create(SERVER_URL)
        .build()

    var messageAndUserState by mutableStateOf<ChatMessage?>(null)

    private val _guid = MutableStateFlow<String>("")

    var messageState by mutableStateOf("")
    var gameCounter by mutableIntStateOf(30)

    private val _isStartState = MutableStateFlow(false)
    val isStartState: StateFlow<Boolean> = _isStartState.asStateFlow()

    private val _currentPlayersNumber = MutableStateFlow(1)
    val currentPlayersNumber: StateFlow<Int> = _currentPlayersNumber.asStateFlow()

    private val _messages = MutableStateFlow(emptyList<ChatMessage>())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _systemMessages = MutableStateFlow(emptyList<SystemMessage>())
    val systemMessages: StateFlow<List<SystemMessage>> = _systemMessages.asStateFlow()

    private val _isDataLoaded = mutableStateOf(false)

    private val _waitingRoomDto = MutableStateFlow<WaitingRoomDto?>(null)
    val waitingRoomDto: StateFlow<WaitingRoomDto?> = _waitingRoomDto.asStateFlow()

    init {
        waitingRoomConnection()
    }

    fun changeGuid(newGuid: String) {
        _guid.value = newGuid
    }

    fun waitingRoomConnection() {
        if(hubConnection.connectionState == HubConnectionState.DISCONNECTED) {
            if(messageAndUserState != null)
                sendPlayerMessage(messageAndUserState!!.user, messageAndUserState!!.message)
            hubConnection.start().doOnComplete{
                setupJoinGame(_guid.value, messageAndUserState?.user ?: "")
                setupReceivePlayers()
                setupReceiveMessage()
                setupSystemMessage()
                if(!_isDataLoaded.value) {
                    ReceiveWaitingRoomData()
                }
            }.subscribe()
        } else {
            Log.d("HUB", "waitingRoomConnection: Already connected")
        }
    }
    fun setupReceivePlayers() {
        hubConnection.on("ReceivePlayers", { players: List<String> ->
            _waitingRoomDto.value = _waitingRoomDto.value?.copy(players = players) ?: _waitingRoomDto.value
        }, List::class.java)
    }
    fun ReceiveWaitingRoomData() {
        hubConnection.on("ReceiveWaitingRoomData", {
            roomId: String,
            roomName: String,
            players: List<String>,
            chosenRoles: List<String>,
            minPlayers: Int,
            maxPlayers: Int ->
            _waitingRoomDto.value = WaitingRoomDto(roomId, roomName, players, maxPlayers, minPlayers, chosenRoles)
            _isDataLoaded.value = true
        }, String::class.java, String::class.java, List::class.java, List::class.java, Int::class.java, Int::class.java)
    }
    fun setupReceiveMessage() {
        hubConnection.on("ReceiveMessage", { user: String, message: String ->
            val newMessage = ChatMessage(user, message)
            _messages.value = _messages.value + newMessage
        }, String::class.java, String::class.java)
    }
    fun sendPlayerMessage(playerName: String, message: String) {
        hubConnection.send("ReceiveMessage", playerName, message)
        messageAndUserState = null
    }
    fun setupJoinGame(guid: String, playerName: String) {
        hubConnection.send("JoinGame", guid, playerName)
    }
    fun setupSystemMessage() {
        hubConnection.on("SystemMessage", { content: String ->
            val newSystemMessage = SystemMessage(content)
            _systemMessages.value = _systemMessages.value + newSystemMessage
        }, String::class.java)
    }
    fun setupStartState() {
        hubConnection.on("isStartState", { isStart: Boolean ->
            _isStartState.value = isStart
        }, Int::class.java)
    }
}