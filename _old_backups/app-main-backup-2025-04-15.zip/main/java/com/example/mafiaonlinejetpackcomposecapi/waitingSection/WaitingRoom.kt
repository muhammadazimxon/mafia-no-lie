package com.example.mafiaonlinejetpackcomposecapi.waitingSection

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mafiaonlinejetpackcomposecapi.roles.Role
import com.example.mafiaonlinejetpackcomposecapi.waitingRoomModels.waitingRoomDto.WaitingRoomDto
import com.example.mafiaonlinejetpackcomposecapi.waitingRoomModels.waitingRoomDtoMessage.WaitingRoomDtoMessage
import com.example.mafiaonlinejetpackcomposecapi.waitingSection.waitingRoomBottomBar.WaitingRoomBottomBar
import com.example.mafiaonlinejetpackcomposecapi.waitingSection.waitingRoomTopBar.WaitingRoomTopBar
import kotlinx.coroutines.delay
import kotlin.random.Random

// roomId, roomName, numberOfPlayers, alowedRoles List<???>,
// FIX: SIZES IN MESSAGES
// OPTIONAL FIX: SIZE IN PLAYERS NAMES IN FIRST LAZY COLUMN

@Composable
fun WaitingRoom(
    modifier: Modifier,
    nextRoom: () -> Unit
) {
    val roomInfo = WaitingRoomDto(
        roomId = "qwerty12345",
        roomName = "Room name",
        minPlayers = 4,
        maxPlayers = 13,
        chosenRoles = listOf("SHERIF", "DON", "BARMAN", "DETECTIVE", "LOVER", "MIFIC", "JOURNALIST", "INFORMATOR", "BOMBER", "CIVILIAN", "MAFIA"),
        players = listOf("Abricos", "Ulug'bek", "Nicole", "HelloWorld", "C#", "Kotlin", "Abricos", "Ulug'bek", "Nicole", "HelloWorld", "C#", "Kotlin")
    )
    val currentPlayersNumber = roomInfo.players.size
    var gameStartCounter by remember { mutableIntStateOf(8) } // ✔✔✔
    val isStartState by remember { mutableStateOf(true) }
    var messageState by remember { mutableStateOf("") }
    val onMessageValueChange = { newMessage: String ->
        messageState = newMessage
    }
    LaunchedEffect(isStartState, gameStartCounter) {
        if (isStartState) {
            while (gameStartCounter > 0) {
                delay(1000)
                gameStartCounter -= 1
            }
            nextRoom()
        }
    }
    val onSubmitMessage = { message: String ->
        println(message)
        messageState = ""
    }
    val messages by remember {
        mutableStateOf(
            listOf(
                WaitingRoomDtoMessage(playerName = "Abricos", message = "Hello guys"),
                WaitingRoomDtoMessage(playerName = "Nicole", message = "Hello guys"),
                WaitingRoomDtoMessage(playerName = "HelloWorld", message = "Hello World"),
                WaitingRoomDtoMessage(playerName = "C#", message = "Hello World"),
                WaitingRoomDtoMessage(playerName = "Kotlin", message = "I am kotlin"),
                WaitingRoomDtoMessage(playerName = "Java", message = "I am javascript, I am javascript, I am javascript, I am javascript, I am javascript, I am javascript, I am javascript, I am javascript, I am javascript, I am javascript"),
                WaitingRoomDtoMessage(playerName = "Kotlin", message = "I am kotlin")
            )
        )
    }
    val roles by remember {
        mutableStateOf(roomInfo.chosenRoles.mapNotNull { name -> Role.fromName(name)?.image })
    }
    val random = remember { Random(System.currentTimeMillis()) }            // 💎💎💎💎💎💎💎💎💎💎

    val playerColors = remember(roomInfo.players) {
        roomInfo.players.map {
            Color(
                red = random.nextInt(100, 256),
                green = random.nextInt(100, 256),
                blue = random.nextInt(100, 256)
            )
        }
    }
    val lazyPaddingValue = (25).dp
    Scaffold(
        containerColor = Color(0xFF1E1E2E),
        contentColor = Color.White,
        topBar = {
            WaitingRoomTopBar(
                roomName = roomInfo.roomName,
                chosenRoles = roles.map { it },
            )
        },
        bottomBar = {
            WaitingRoomBottomBar(
                value = messageState,
                onValueChange = onMessageValueChange,
                onSubmit = onSubmitMessage
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier.padding(innerPadding)
                .fillMaxSize()
                .padding(horizontal = 6.dp)
        ) {
            HorizontalDivider()
            Spacer(modifier = Modifier.height(5.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Players in the room [${roomInfo.minPlayers}/${roomInfo.maxPlayers}]: $currentPlayersNumber",
                    color = Color(0xFFFFD700)
                )
                Text(
                    text = "Game will start in $gameStartCounter sec",
                    color = Color(0xFFFFD700)
                )
            }
            Spacer(modifier = Modifier.height(5.dp))
            Row(
                modifier = Modifier.fillMaxWidth()
                    .height(210.dp)
                    .background(Color(0xFF2E2E3E))
                    .border(2.dp, Color(0xFF7B68EE), RoundedCornerShape(12.dp))
            ) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.fillMaxSize()
                        .padding(lazyPaddingValue),
                    verticalArrangement = Arrangement.spacedBy(15.dp)
                ) {
                    itemsIndexed(roomInfo.players) { index, it ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier.size(25.dp)
                                    .clip(CircleShape)
                                    .background(playerColors[index]),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = it.first().uppercase(),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.W400
                                )
                            }
                            Text(
                                text = it,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.W500,
                            )
                        }
                    }
                }
            }
            Row(
                modifier = Modifier.padding(top = 5.dp, bottom = 5.dp)
                    .fillMaxSize()
                    .background(Color(0xFF2E2E3E))
                    .border(2.dp, Color(0xFF7B68EE), RoundedCornerShape(12.dp))
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = lazyPaddingValue, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    itemsIndexed(messages) { index, it ->
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier.size((18 + 8 + 16).dp)
                                    .clip(CircleShape)
                                    .background(playerColors[index]),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = it.playerName.first().uppercase(),
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.W400
                                )
                            }
                            Column(
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    modifier = Modifier.width(120.dp),
                                    text = it.playerName,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.W600,
                                    maxLines = 1,
                                    minLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    modifier = Modifier.widthIn(max = 250.dp)
                                        .wrapContentHeight(),
                                    text = it.message,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.W400,
                                    softWrap = true
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
@Preview(showBackground = true)
fun WaitingRoomPreview() {
    WaitingRoom(modifier = Modifier, {})
}