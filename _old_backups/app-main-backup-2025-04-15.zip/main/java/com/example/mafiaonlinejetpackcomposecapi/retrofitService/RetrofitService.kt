package com.example.mafiaonlinejetpackcomposecapi.retrofitService

import com.example.mafiaonlinejetpackcomposecapi.mainMenu_JoinRoomSection.RoomData
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

private const val BASE_URL = "http://10.0.2.2:5020/"

private val retrofit = Retrofit.Builder()
    .addConverterFactory(GsonConverterFactory.create())
    .baseUrl(BASE_URL)
    .build()

interface MafiaApiService {
    @GET("update")
    suspend fun update(): List<RoomData>
    @GET("game-guid")
    suspend fun gameGuid(): String
}

object MafiaApi {
    val retrofitService: MafiaApiService by lazy {
        retrofit.create(MafiaApiService::class.java)
    }
}